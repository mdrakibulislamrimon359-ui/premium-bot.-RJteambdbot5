# Firebase helper placeholder
