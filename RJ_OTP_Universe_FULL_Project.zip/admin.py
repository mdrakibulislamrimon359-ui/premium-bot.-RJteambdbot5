# Admin panel placeholder
