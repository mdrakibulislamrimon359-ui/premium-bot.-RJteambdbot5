# RJ OTP Universe Bot

Render-ready Telegram bot starter with user profiles, balance ledger,
referrals, admin controls, blocking and broadcast.

This version intentionally does not automate buying, intercepting, or forwarding
third-party verification OTPs. The OTP module is only a safe provider boundary.

## Render
Build: `pip install -r requirements.txt`
Start: `python bot.py`

Environment:
- BOT_TOKEN = Telegram bot token
- ADMIN_USERNAME = RJteam1 (or your admin username)
- ADMIN_IDS = optional comma-separated Telegram numeric IDs
- DATABASE_PATH = optional SQLite path

## Service selector

The bot now has a service-selection menu similar to the requested layout.
Each service is isolated: selecting a service only searches that service's
admin-added authorized test-number pool.

Admin command:
`/addnumber SERVICE TEST_NUMBER`

Example:
`/addnumber telegram +8801XXXXXXXXX`

The bot does not retrieve, intercept, or forward third-party verification OTPs.

## v3 UI update
- `/number` opens the service selector directly.
- `/start` shows a `📱 Get Number` button.
- Services are shown as inline buttons rather than a plain text list.
- Users should tap a service button; typing `1` is not required.
